# SolGod Dashboard

Our advanced anti-fraud system is designed to protect both you and our service. Please note that SolGod trial version is restricted from running on:

- Dedicated servers
- Virtual machines (VMs)
- VPS/Cloud instances
- Shared hosting environments

Trial version is designed for personal desktop use only. Installation on restricted environments will be automatically blocked by our security system.

💎 **Full License Benefits**

When you purchase a SolGod license, these restrictions are removed and you gain:

- Unlimited deployment options – run on any environment including VPS, cloud instances, and dedicated servers
- Enterprise-grade flexibility – deploy across multiple machines and environments
- 24/7 technical support – priority assistance for all deployment scenarios
- Commercial usage rights – use SolGod for business operations without limitations

👉 **Purchase your license today**

💬 **Need Help?**

If you encounter any difficulties during installation or have questions about using SolGod, feel free to reach out to us on Telegram: [@SolGodSuite_bot](https://t.me/SolGodSuite_bot)

We're here to help make your experience as smooth as possible!

---

## Dashboard

The **Dashboard** is your main hub for monitoring and managing SolGod activities in real time. It provides an immediate overview of key metrics, bot activity, and licensing status.

---

## Features

### 1. Total Balance Card
- Displays your current SOL balance and its USD equivalent.
- Auto-refreshes every 30 seconds.
- Supports manual refresh by clicking on the card.

### 2. Active Bots Card
- Lists all your currently running bots with status indicators:
  - **Active**
  - **Stopped**
  - **Error**
- Clicking on a bot opens a detailed view of that bot.

### 3. Recent Launches Card
- Shows the latest 10 token launches with:
  - Timestamps
  - Status (e.g. "Success", "Pending")
  - Links to token details and Solana Explorer

### 4. License/Trial Status Card
- Displays a visual progress bar indicating how many days remain on your trial or license.
- Upon expiry, a modal prompts you to renew or upgrade your license.

---

## User Flow

1. After logging in, you're directed straight to the Dashboard.
2. All cards auto-update in real time. You can also refresh any card manually.
3. Click on any bot or launch item to open its detailed view.
4. If your trial or license expires, a modal will appear with renewal options.

---

## Implementation Details

- **Background Polling**: Balances and bot statuses are automatically fetched in background threads.
- **Persistent Activity Log**: All user actions and system errors are logged and accessible for reference.
- **Extensible Widgets**: Developers can add custom dashboard widgets via a plugin API for further customization.

---

## Preview (Illustrative)

```
Dashboard:

┌──────────────────┐   ┌──────────────────────┐   ┌────────────────────────┐   ┌─────────────────────────┐
│ Total Balance    │   │ Active Bots          │   │ Recent Token Launches  │   │ License / Trial Status  │
│ 25.42 SOL        │   │ 2 Running            │   │ SOLDOGE – Success      │   │ 10 days remaining       │
│ ~$1,284.56       │   │ Arbitrage Bot – Active │ SAMO2.0 – Pending      │   │ [████████▉     ]        │
└──────────────────┘   │ MEV Sniper – Paused  │   │ (View All)             │   │ (Renew / Upgrade)       │
                       └──────────────────────┘   └────────────────────────┘   └─────────────────────────┘
```

---


